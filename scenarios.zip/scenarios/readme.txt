Repository contains 180 randomly generated gossip scenarios. 20 scenarios for each node number 4, 5, 6, 10, 12, 15, 20, 30, 50.
Scenarios are stored as .csv files with the following columns:  

node_id - Node numeric identifier
index - Event index in node event sequence 
timestamp - Event creation timestamp
self_parent_index - Index of event self-parent
other_parent_node_id - Other parent numeric identifier
other_parent_index - Index of event other parent
